<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         .about-container{
   background-color: antiquewhite;
   margin-top: 20%;
 
 }
 @media screen and (max-width: 600px) {
    .about-container{
      margin-top: 55%;
    }   
 }
 .about h1 {
   text-align: center;
 }
 .about p{
   text-align: center;
 }
  .btn1{
   margin-left: 45%;
    width: 100px;
    background: brown;
    border-radius: 8px;
    border: none;
    height: 35px;
 }
 .btn1 a{
    text-decoration: none;
 }
 hr{
    border-color: #000;
    margin-top: 20%;
 }
 @media screen and (max-width: 600px) {
     hr{
        margin-top: 50%;
     }
     
 }
    </style>
</head>
<body>
 
    <section>
<div class="about-container">
<div class="about">
  <h1>About us</h1>
  <p>Decades of matchmaking expertise, exemplified by 'Patrapatri' (matrimonial classifieds)
     got reinvented online in the form of <br> ABPweddings.com.
     As society evolved, the decision making pertaining to marriage became collaborative.</p>
     <button class="btn1"><a href="readmore.php"> Read More</a></button>
  </div>
</div>
</section>
</body>
</html>