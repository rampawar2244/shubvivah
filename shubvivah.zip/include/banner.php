<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
         
.images img {
    width: 100%;
    height: 50%;
    
}
    </style>
</head>
<body>
<div class="images">
<img src="images/marathi1.png" alt="">
</div>
</body>
</html>