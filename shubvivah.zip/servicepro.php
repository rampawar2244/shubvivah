<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/service.css">
    <title>Service-Provider</title>
</head>
<body>
    <div class="heading">
    <h1>Our Service Provider</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti distinctio, laboriosam voluptas commodi error nulla, natus dignissimos ipsum praesentium iste rerum laborum animi minus expedita obcaecati, explicabo numquam odio magni.</p>
   </div>
<div class="row">
  <div class="column">
    <h2>caters</h2>
    <p>Some text..</p>
    <button class="btn" type="book">Book Now</button>
</div>
  <div class="column">
    <h2>Pandit</h2>
    <p>Some text..</p>
    <button class="btn" type="book">Book Now</button>

  </div>
  <div class="column">
    <h2>D.j system</h2>
    <p>Some text..</p>
    <button class="btn" type="book">Book Now</button>

  </div>
  <div class="column">
    <h2>wedding planer</h2>
    <p>Some text..</p>
    <button class="btn" type="book">Book Now</button>

  </div>
</div>
<div class="heading">

<h1>Register For Service Provider</h1>
</div>
<div class="container">
			<div class="main">
				<div class="main-center">
			
					<form class="" method="post" action="#">
						
						<div class="form-group">
							<label for="name">Your Name</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
				<input type="text" class="form-control" name="name" id="name"  placeholder="Enter your Name"/>
							</div>
						</div>

						<div class="form-group">
							<label for="email">Your Email</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="email" placeholder="Enter your Email"/>
							</div>
						</div>

						<div class="form-group">
							<label for="username">Type Of service</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="username" placeholder="Enter your Username"/>
								</div>
						</div>

						<div class="form-group">
							<label for="password">Details</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password" placeholder="Enter your Password"/>
								</div>
						</div>

						

				<button class="btn1" type="submit">SUBMIT</button>
						
					</form>
				</div><!--main-center"-->
			</div><!--main-->
		</div><!--container-->
</body>
</html>