 <!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Shubh Vivah</title>
 </head>
 <body>
  <?php
include_once('include/nav.php');
include_once('include/banner.php');
include_once('include/search.php');
include_once('include/slider.php');
include_once('include/happystory.php');
include_once('include/slider2.php');
include_once('include/slidephoto.php');
include_once('include/about.php');
include_once('include/photoinfo.php');
include_once('include/footer.php');

  ?>
 </body>
 </html>